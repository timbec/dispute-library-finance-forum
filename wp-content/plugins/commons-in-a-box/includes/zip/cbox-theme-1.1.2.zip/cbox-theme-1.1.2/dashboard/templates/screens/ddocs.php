<div class="infinity-docs infinity-docs-page">
	<?php infinity_dashboard_devdoc_publish( infinity_screens_route_param( 1 ) ); ?>
</div>
<div class="infinity-docs infinity-docs-toc">
	<?php infinity_dashboard_devdoc_publish( '_toc' ); ?>
</div>
<div class="ui-helper-clearfix"></div>