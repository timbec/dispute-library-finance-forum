<?php
	infinity_widget( 'debugger' );
?>
