/*
WebFont.load({
	google: {
		families: [
			'Tangerine',
			'Cantarell',
			'Droid Sans',
			'Crushed'
		]
	}
});
*/