WordPress theme for Commons In A Box OpenLab project

[![Build Status](https://travis-ci.org/cuny-academic-commons/openlab-theme.svg?branch=1.1.x)](https://travis-ci.org/cuny-academic-commons/openlab-theme)

Part of the Commons In A Box project https://github.com/cuny-academic-commons/commons-in-a-box.
